<?php
setcookie('setByPHP', 'test');
echo $_COOKIE['setByPHP'];

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>

</body>
</html>
