<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <style>
    span {
      width: 100px;
      height: 100px;
      background-color: pink;
      display: inline-block;
    }
  </style>
</head>
<body>
  <?php
    include '2-link.php';
   ?>
</body>
</html>
