<?php
header('Content-Type: text/css');
echo "body {
  background-color: red;
}";
