<?php
header('Content-Type: text/html');
echo "<span></span>";
