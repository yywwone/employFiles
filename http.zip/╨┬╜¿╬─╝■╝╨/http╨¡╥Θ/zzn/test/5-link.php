<?php
$data = "back";
header('Content-Type: application/json');
echo json_encode($data);
